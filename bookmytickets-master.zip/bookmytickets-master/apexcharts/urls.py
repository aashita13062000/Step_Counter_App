from django.urls import path
from apexcharts.models import bigbasket
from customers import views
from .views import *

urlpatterns = [
     path('v1/bigbasket/',BigBasket.as_view(),name = 'customeranalytics'),
]
