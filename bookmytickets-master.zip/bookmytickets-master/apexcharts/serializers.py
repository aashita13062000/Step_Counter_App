# from django.urls import path, include
import datetime
from django.contrib.auth.models import User
from rest_framework import routers, serializers, viewsets
from rest_framework.validators import UniqueValidator
from .models import *
import uuid
from datetime import datetime, timedelta


class SearchBigBasketSerializer(serializers.ModelSerializer):
    class Meta:
        model = bigbasket
        fields = '__all__'
