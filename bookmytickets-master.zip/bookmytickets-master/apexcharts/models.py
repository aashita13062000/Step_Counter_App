from django.db import models

class bigbasket(models.Model):
	product = models.CharField(max_length=100)
	category =models.CharField(max_length=100)
	sub_category = models.CharField(max_length=100)
	brand = models.CharField(max_length=100)
	sale_price = models.CharField(max_length=100)
	market_price = models.PositiveIntegerField()
	type= models.CharField(max_length=100,null=True,blank=True)
	rating = models.FloatField(null=True,blank=True)
	description = models.TextField(null=True,blank=True)
	created_at = models.DateField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	def __str__(self):
		return str(self.product)