from operator import truediv
import re
from rest_framework.decorators import api_view,permission_classes,throttle_classes
from rest_framework.views import APIView,View
from rest_framework.response import Response
from django.contrib.auth.models import User
from rest_framework import generics,status
from rest_framework.permissions import IsAuthenticated,IsAdminUser,AllowAny
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
import base64
from django.http import HttpResponse,JsonResponse
from django.http import HttpResponse, Http404
from rest_framework.viewsets import ViewSet
from django.shortcuts import render
from rest_framework.throttling import UserRateThrottle
from django.shortcuts import render,get_object_or_404
from django.db.models import F
from django.db.models import Q
from django.db.models import Count,Sum
from django.db.models.functions import ExtractMonth
from rest_framework.settings import api_settings
from .models import *
from .serializers import *

class BigBasket(APIView):
    pagination_class = api_settings.DEFAULT_PAGINATION_CLASS
    serializer_class = SearchBigBasketSerializer

    @property
    def paginator(self):
        if not hasattr(self, '_paginator'):
            if self.pagination_class is None:
                self._paginator = None
            else:
                self._paginator = self.pagination_class()
        else:
            pass
        return self._paginator
    def paginate_queryset(self, queryset):
        
        if self.paginator is None:
            return None
        return self.paginator.paginate_queryset(queryset,
                   self.request, view=self)
    def get_paginated_response(self, data):
        assert self.paginator is not None
        return self.paginator.get_paginated_response(data)
    # def get(self, request, format=None, *args, **kwargs):
    #     instance = bigbasket.objects.all()
    #     page = self.paginate_queryset(instance)
    #     if page is not None:
    #         serializer = self.get_paginated_response(self.serializer_class(page,many=True).data)
    #     else:
    #         serializer = self.serializer_class(instance, many=True)
    #     return Response(serializer.data, status=status.HTTP_200_OK)

    def get(self,request):
        if 'search' in request.GET:
            context={}
            instance = bigbasket.objects.filter(product__icontains=request.GET.get('search'))
            page = self.paginate_queryset(instance)
            if page is not None:
                serializer = self.get_paginated_response(self.serializer_class(page,many=True).data)
            else:
                serializer = self.serializer_class(instance, many=True)
            context['prodduct_table_data'] = serializer.data
        else:

            categories = set(bigbasket.objects.values_list('category',flat=True))
            context={}
            context['total_products'] = bigbasket.objects.all().count()
            context['categories'] = len(categories)
            context['brands'] = len(set(bigbasket.objects.values_list('brand')))
            context['5starproducts'] = bigbasket.objects.filter(rating__icontains=5).count()
            context['cat_x_axis'] = list(categories)
            context['cat_y_axis'] = []
            for cat in context['cat_x_axis']:
                no = bigbasket.objects.filter(category=cat).count()
                context['cat_y_axis'].append(no)
            context['main_data'] = dict(zip(context['cat_x_axis'],context['cat_y_axis']))
            context['rating_x_axis'] = [1,2,3,4,5]
            context['rating_y_axis'] = []
            for i in context['rating_x_axis']:
                context['rating_y_axis'].append(bigbasket.objects.filter(rating__gte=i,rating__lte=i+1).count())


            instance = bigbasket.objects.all()
            page = self.paginate_queryset(instance)
            if page is not None:
                serializer = self.get_paginated_response(self.serializer_class(page,many=True).data)
            else:
                serializer = self.serializer_class(instance, many=True)

            context['prodduct_table_data'] = serializer.data
        return JsonResponse(context, safe=False)
