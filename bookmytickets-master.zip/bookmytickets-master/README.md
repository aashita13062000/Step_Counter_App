<h4>About The Project:</h4>

“BookMyTickets” offers a central platform for booking flight tickets at discounted rates.
This task involves developing backend REST APIs inorder to add various features to the platform.


<h4>Built With</h4>
<ul>
  <li>Python : 3.8</li>
  <li>Back-End : Django and Django Rest Framework</li>
  <li>Database : Postgresql</li>
</ul> 


<h4>Prerequisites</h4>
<b>Install Postgres</b> : 
<ul>
  <li>Postgres</li>
  <pre>sudo apt install postgresql postgresql-client</pre>
</ul> 


<h4>Installation</h4>
<pre>

pip install virtualenv

git clone https://github.com/shivakrishnakonanki/booktickets.git

cd BookMyTickets 

virtualenv venv

source venv/bin/activate

pip install -r requirements.txt

</pre>

<b>Before running application follow below process : </b>
<br>

    modify the database settings in .env file
    python manage.py runserver
