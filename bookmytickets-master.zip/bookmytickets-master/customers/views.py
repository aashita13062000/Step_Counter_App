from operator import truediv
import re
from rest_framework.decorators import api_view,permission_classes,throttle_classes
from rest_framework.views import APIView,View
from rest_framework.response import Response
from django.contrib.auth.models import User
from rest_framework import generics
from rest_framework import status
from rest_framework.permissions import IsAuthenticated,IsAdminUser,AllowAny
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
import base64
from django.http import HttpResponse,JsonResponse
from django.http import HttpResponse, Http404
from rest_framework.viewsets import ViewSet
from .serializers import *
import json
from django.shortcuts import render
from rest_framework.throttling import UserRateThrottle


@api_view(['GET'])
@permission_classes([AllowAny])
def activate(request):
    if request.method == 'GET':
        try:
            activate =request.GET.get('activate')
            user_details = base64.b64decode(activate.encode("ascii")).decode("ascii").split(',')
            user = User.objects.get(email=user_details[0],
                                    username=user_details[1],)
            user.is_active = True
            user.save()
        except Exception as e:
            return HttpResponse("<h1>While trying to activate we have below error : <br/>{0}</h1>".format(e))
        return HttpResponse("<h1>Now you can login thanks for activation</h1>")

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        response = super().create(request, *args, **kwargs)
        user = User.objects.filter(username=response.data['username'],
                                    email=response.data['email']).first()
        activation_token = user.email+','+user.username+','+str(user.date_joined)
        activation_token = activation_token.encode("ascii")
        base64_bytes = base64.b64encode(activation_token)
        base64_string = base64_bytes.decode("ascii")

        if self.request.is_secure():
            httpsecure='https://'
        else:
            httpsecure= 'http://'

        url_for_activation = httpsecure+request.get_host() + '/accounts/activate/'+'?activate='+base64_string
        return Response({
            'status': 201,
            'message' : 'we have succussfully added to database please activate account by clicking above url',
            'activation_link':url_for_activation,
            'data': response.data
        })

class LoginView(APIView):
    # authentication_classes = [BasicAuthentication]
    permission_classes = [IsAuthenticated]
    def get(self, request, format=None):
        items = User.objects.get(id = request.user.id)
        serializer = UserallSerializer(items)
        return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)

class UserUpdateView(generics.UpdateAPIView):
    # authentication_classes = [BasicAuthentication]
    permission_classes = [IsAuthenticated]
    lookup_field = "pk"
    serializer_class = UserSerializer

    def get_object(self):
        obj=User.objects.get(username=self.request.user.username)
        return obj

    def update(self, request, *args, **kwargs):
       partial = kwargs.pop('partial', False)
       instance = self.get_object()
       serializer = self.get_serializer(instance, data=request.data, partial=partial)
       serializer.is_valid(raise_exception=True)
       self.perform_update(serializer)
       result = {
        "message": "success",
        "details": serializer.data,
        "status": 200,
       }
       return Response(result)


    def get(self, request, *args, **kwargs):
        instance = self.get_object()
        serializer = self.get_serializer(instance)
        # result = {"data": serializer.data,}
        return Response(serializer.data)