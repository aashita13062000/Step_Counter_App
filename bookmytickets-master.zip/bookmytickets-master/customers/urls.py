from django.urls import path
from customers import views
from .views import *
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
app_name='customers'
urlpatterns = [

    #user login-User -->can update his only profile
    path('v1/register/',RegisterView.as_view(),name = 'register'),
    path('activate/', views.activate, name='activate'),
    path('v1/login/',LoginView.as_view(),name = 'login-register'),
    path('v1/user-update/',UserUpdateView.as_view(),name = 'user-update'),

]