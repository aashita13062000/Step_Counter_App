from django.contrib.auth.base_user import BaseUserManager


class CustomUserManager(BaseUserManager):
    def create_user(self,username, email, password, **extra_fields):
        if not username:
            raise ValueError("The username must be set")
        if not password:
            raise ValueError("The password must be set")
        user = self.model(email=self.normalize_email(email), **extra_fields)
        user.username=username
        user.set_password(password)
        user.save()
        return user
