from django.db import models
from django.contrib.auth.models import User
from phonenumber_field.modelfields import PhoneNumberField
from django.core.validators import MaxValueValidator
from django.contrib.auth.models import AbstractUser
from .managers import CustomUserManager

# Create your models here.

GENDER_CHOICES =(
    ("Male", "Male"),
    ("Female", "Female"),
    ("Other", "Other"),
)

class User(AbstractUser):
    gender = models.CharField(choices=GENDER_CHOICES,max_length=10,null=True,blank=True)
    contact_number = PhoneNumberField(blank=True, null=True)
    DOB = models.DateField(null=True,blank=True)
    age = models.PositiveIntegerField(null=True,blank=True,validators=[MaxValueValidator(150)])
    country = models.CharField(max_length=30,null=True,blank=True)
    state = models.CharField(max_length=30,null=True,blank=True)
    city = models.CharField(max_length=30,null=True,blank=True)
    pincode = models.PositiveIntegerField(null=True,blank=True,validators=[MaxValueValidator(9999999)])

    objects = CustomUserManager()

    def __str__(self):
        return self.username