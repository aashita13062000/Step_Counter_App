from rest_framework.test import APITestCase
from customers.models import User

class TestUserModel(APITestCase):
    def setUp(self):
        self.user_data={'username':"username",'email':"email@test.com","password": "password"}

    def test_creates_user(self):
        user = User.objects.create(username="username",email="email@test.com",password="password")
        self.assertIsInstance(user,User)
        self.assertEqual(user.email, "email@test.com")
