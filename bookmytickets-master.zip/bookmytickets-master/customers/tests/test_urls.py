from django.urls import reverse,resolve
from customers.views import *
from django.test import SimpleTestCase

class TestUrls(SimpleTestCase):
    def test_register(self):
        url=reverse("customers:register")
        self.assertEqual(resolve(url).func.view_class ,RegisterView)

    def test_login(self):
        url=reverse("customers:login-register")
        self.assertEqual(resolve(url).func.view_class ,LoginView)

    def test_user_update(self):
        url=reverse("customers:user-update")
        self.assertEqual(resolve(url).func.view_class ,UserUpdateView)