from django.contrib.auth.models import User
from django.urls import reverse
from rest_framework import HTTP_HEADER_ENCODING,status
from rest_framework.authtoken.models import Token
from rest_framework.test import APITestCase
from customers.models import User
import json

# Registration Test
class RegistrationTestCase(APITestCase):
    def test_registration(self):
        data = {"username": "susttest", 
                "email": "custtest@gmail.com",
                "password": "testuser",
                "password2": "testuser"
                }
        response = self.client.post("/accounts/v1/register/", data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        response_for_activation = self.client.get(path=response.data['activation_link'])
        self.assertEqual(response_for_activation.status_code, status.HTTP_200_OK)
        response_for_wrong_activation = self.client.get(path=response.data['activation_link']+'test')
        self.assertEqual(response_for_wrong_activation.status_code, status.HTTP_200_OK)
        
    def test_registration_without_data(self):
        response = self.client.post("/accounts/v1/register/")
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

# Login Test
class LoginTestCase(APITestCase):
    def test_correct_authentication(self):
        self.user1=User.objects.create_user(username= "test", 
                                            email= "test@gmail.com",
                                            password= "password",
                                            is_active=True)
        res_token = self.client.post(path=reverse('token_obtain_pair'),
                                    data={"username": "test","password": "password"}
                                    )
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {res_token.data['access']}")
        response = self.client.get(path="/accounts/v1/login/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
    def test_wrong_password(self):
        self.user1=User.objects.create_user(username= "wrongtest", email= "wrongtest@gmail.com",password= "password",is_active=True)
        res_token = self.client.post(path=reverse('token_obtain_pair'),data={"username": "wrongtest","password": "pass"})
        self.assertEqual(res_token.status_code, status.HTTP_401_UNAUTHORIZED)
       
# User update personal data
class UserDataUpdateTestCase(APITestCase):
    def setUp(self):
        self.data = {"username": "test1", 
                "email": "test@gmail.com",
                "password": "testuser",
                # "password2": "testuser"
                }

        self.user = User.objects.create_user(**self.data)

    #Get Access Tokens
    def get_token(self,username,password):
        token = self.client.post(path=reverse('token_obtain_pair'),data={"username":username,"password":password})
        return token
    
    # Retrive Data from the User Table
    def test_user_retrive_data(self):
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {self.get_token(username=self.data['username'],password=self.data['password']).data['access']}")
        response = self.client.get(reverse("customers:user-update"))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    # User unauthenticated trying to access
    def test_unauthenticated_retrive_data(self):
        username="unauthenticated"
        password="password"
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {self.get_token(username=username,password=password).data['detail']}")
        response = self.client.get(reverse("customers:user-update"))
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
    
     #testing for updating user data
    def test_user_update(self):
        username=self.data['username']
        password=self.data['password']
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {self.get_token(username=username,password=password).data['access']}")
        input_data= {
            'gender': 'Male',
            'DOB': '2020-11-28',
            'age': '30',
            'country': 'India',
            'state': "Karnataka",
            'city': 'Banglore',
            'pincode': '560035'
        }
        response = self.client.put(reverse("customers:user-update"),
                                data=json.dumps(input_data), 
                                content_type='application/json')

        self.assertEqual(response.status_code, status.HTTP_200_OK)


     #testing for updating user data
    def test_user_update(self):
        username=self.data['username']
        password=self.data['password']
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {self.get_token(username=username,password=password).data['access']}")
        input_data= {
            'gender': 'Male',
            'DOB': '2029-11-28',
            'age': '30',
            'country': 'India',
            'state': "Karnataka",
            'city': 'Banglore',
            'pincode': '560035'
        }
        response = self.client.put(reverse("customers:user-update"),
                                data=json.dumps(input_data), 
                                content_type='application/json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

