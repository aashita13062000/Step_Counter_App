from django.db import models
from django.contrib.auth.models import User
from phonenumber_field.modelfields import PhoneNumberField
from django.core.validators import MaxValueValidator
from .misc import CountryField
from customers.models import *

class Airports(models.Model):
	country_code = CountryField(max_length=2)
	airport_name = models.CharField(max_length=40,unique=True)

	def __str__(self):
		return str(self.airport_name)

class Flights(models.Model):
	airport = models.ForeignKey(Airports, on_delete=models.PROTECT)
	flight_number = models.CharField(max_length=40,unique=True)
	depart_date_time = models.DateTimeField()
	arival_date_time = models.DateTimeField()
	origin = models.CharField(max_length=100)
	destination = models.CharField(max_length=100)
	price = models.PositiveIntegerField()
	city = models.CharField(max_length=30)
	airlines_name = models.CharField(max_length=100)
	aviliable_seats = models.PositiveIntegerField(validators=[MaxValueValidator(999)])
	total_seats = models.PositiveIntegerField(validators=[MaxValueValidator(999)],null=True,blank=True)
	created_at = models.DateField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True)

	def __str__(self):
		return str(self.flight_number)

BOOKING_STATUS =(
    ("InProgress", "InProgress"),
    ("Booked", "Booked"),
    ("cancelled","cancelled")
)

class Booking(models.Model):
	booked_by = models.CharField(max_length=50,null=True,blank=True)
	name = models.CharField(max_length=40,null=True,blank=True)
	gender = models.CharField(max_length=10,null=True,blank=True)
	DOB = models.DateField(null=True,blank=True)
	contact_number = PhoneNumberField(blank=True, null=True)
	flights = models.ForeignKey(Flights, on_delete=models.PROTECT)
	booking_number = models.CharField(max_length=15)
	pnr_number = models.CharField(max_length=15)
	booking_status = models.CharField(choices=BOOKING_STATUS,default = "Booked",max_length=30,null=True,blank=True)
	created_at = models.DateField(auto_now_add=True)
	updated_at = models.DateTimeField(auto_now=True) 

	def __str__(self):
		return str(self.pnr_number)

