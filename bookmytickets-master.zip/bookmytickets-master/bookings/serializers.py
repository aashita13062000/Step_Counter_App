# from django.urls import path, include
import datetime
from django.contrib.auth.models import User
from rest_framework import routers, serializers, viewsets
from rest_framework.validators import UniqueValidator
from .models import *
import uuid
from datetime import datetime, timedelta

class AdminAirportsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Airports
        fields = ('country_code','airport_name') 

class AdminFlightsSerializer(serializers.ModelSerializer):
    airport_name = serializers.CharField(write_only=True)
    country_code = serializers.CharField(write_only=True)
    class Meta:
        model = Flights
        fields = ('airport_name','flight_number','depart_date_time', 'arival_date_time','origin','destination','price',
                    'city','airlines_name','aviliable_seats','total_seats','country_code',)
    

    def validate(self, data):
        if data['airport_name']:
            try:
                 Airports.objects.get(airport_name=data['airport_name'],
                                        country_code=data['country_code'])
            except Exception as e:
                raise serializers.ValidationError({"airport": str(e)})
        return data

    def create(self, validated_data):
        Airports_instance = Airports.objects.get(airport_name=validated_data.pop('airport_name'),
                                                country_code=validated_data.pop('country_code'))
        Flights_instance = Flights.objects.create(**validated_data, airport=Airports_instance)
        return Flights_instance


class CustomerBookingDetailsSerializer(serializers.Serializer):
    class Meta:
        model = Booking
        fields = '__all__'

class CustomerBookingSerializer(serializers.Serializer):
    flight_number = serializers.CharField(write_only=True)
    name = serializers.CharField()
    gender = serializers.CharField()
    DOB = serializers.CharField()
    contact_number = serializers.CharField()

    class Meta:
        model = Booking
        fields = ('flight_number',"name","gender","DOB","contact_number",)

    def validate(self, data):
        if data['flight_number']:
            try:
                 Flights.objects.get(flight_number=data['flight_number'])
            except Exception as e:
                raise serializers.ValidationError({"flight_number": str(e)})
        return data

    def create(self, validated_data):
        flight_instance = Flights.objects.get(flight_number=validated_data['flight_number'])
        print("!!",flight_instance)
        Flights_instance = Booking.objects.create(flights = flight_instance,
                                                booked_by = self.context['booked_by'],
                                                booking_number = str(flight_instance.airport.country_code)+str(flight_instance.flight_number)+\
                                                        str(uuid.uuid4().int)[:4],
                                                pnr_number = self.context['pnr'],
                                                name = validated_data["name"],
                                                gender = validated_data["gender"],
                                                DOB = validated_data["DOB"],
                                                contact_number = validated_data["contact_number"])
        return Flights_instance



class SearchFlightsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Flights
        fields = '__all__'

class UserBookedSerializer(serializers.ModelSerializer):
    flight_departure_time = serializers.CharField(source='flights.depart_date_time')
    cancel_ticket = serializers.SerializerMethodField('is_cancel_ticket')

    def is_cancel_ticket(self,obj):
        if obj.booking_status =='cancelled':
            return 'cancelled'
        else:    
            if  obj.flights.depart_date_time.replace(tzinfo=None) > datetime.now()+timedelta(days = 2):
                return "true"
            elif obj.flights.depart_date_time.replace(tzinfo=None) < datetime.now():
                return "departed"
            else:
                return "false"
    class Meta:
        model = Booking
        fields = ['cancel_ticket','flight_departure_time','booked_by','name',
                'gender','DOB','contact_number','flights','booking_number',
                'pnr_number','booking_status','created_at','updated_at','id']
