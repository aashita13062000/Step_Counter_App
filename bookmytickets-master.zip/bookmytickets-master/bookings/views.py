
from operator import truediv
import re
from rest_framework.decorators import api_view,permission_classes,throttle_classes
from rest_framework.views import APIView,View
from rest_framework.response import Response
from django.contrib.auth.models import User
from rest_framework import generics,status
from rest_framework.permissions import IsAuthenticated,IsAdminUser,AllowAny
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
import base64
from django.http import HttpResponse,JsonResponse
from django.http import HttpResponse, Http404
from rest_framework.viewsets import ViewSet
from django.shortcuts import render
from rest_framework.throttling import UserRateThrottle
from .serializers import *
from django.shortcuts import render,get_object_or_404
from django.db.models import F
from django.db.models import Q
from django.db.models import Count,Sum
from django.db.models.functions import ExtractMonth
from rest_framework_simplejwt.authentication import JWTAuthentication



class AdminCreateAirportDataView(ViewSet):
    queryset = Airports.objects.all()

    def list(self, request):
        serializer = AdminAirportsSerializer(self.queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None):
        item = get_object_or_404(self.queryset, pk=pk)
        serializer = AdminAirportsSerializer(item)
        return Response(serializer.data)

    def create(self, request):
        serializer = AdminAirportsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk, format=None, *args, **kwargs):
        airport_data = get_object_or_404(Airports.objects.all(), pk=pk)
        serializer = AdminAirportsSerializer(airport_data, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request, pk, format=None):
        airport_data = get_object_or_404(Airports.objects.all(), pk=pk)
        airport_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class AdminCreateFlightDataView(ViewSet):
    queryset = Flights.objects.all()

    def list(self, request):
        serializer = AdminFlightsSerializer(self.queryset, many=True)
        return Response(serializer.data)

    def retrieve(self, request, pk=None):
        item = get_object_or_404(self.queryset, pk=pk)
        serializer = AdminFlightsSerializer(item)
        return Response(serializer.data)

    def create(self, request):
        serializer = AdminFlightsSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk=None):
        airport_data = get_object_or_404(Flights.objects.all(), pk=pk)
        serializer = AdminFlightsSerializer(airport_data, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request, pk, format=None):
        airport_data = get_object_or_404(Flights.objects.all(), pk=pk)
        airport_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class CustomerBooking(APIView):
    # authentication_classes = [BasicAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request, format=None):
        pnr_number = str(uuid.uuid4().int)[:8]
        serializer = CustomerBookingSerializer(data=request.data,many=True,
                                                context={'request': request,
                                                "pnr":pnr_number,
                                                "booked_by":self.request.user.username})
        if serializer.is_valid():
            serializer.save()
            context={}
            context["success"] = "Your Flight has been booked with PNR number for your reference "+ str(pnr_number)
            return Response(context, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



@api_view(['GET'])
@permission_classes([AllowAny])
def CustomerBookingStatus(request,pnr_number):
    if request.method == 'GET':
        
        booking_instance = Booking.objects.filter(pnr_number=pnr_number).values('pnr_number',
                                                                                 'name',"gender",
                                                                                 "DOB","contact_number",
                                                                                 "booking_status","updated_at")

        return JsonResponse({'results': list(booking_instance)})


class SearchFlights(generics.ListAPIView):
    queryset = Flights.objects.all()
    serializer_class = SearchFlightsSerializer

    def get_queryset(self):
        if self.request.GET.get('search'):
            queryset = Flights.objects.filter(Q(origin__icontains=self.request.GET.get('search'))|
                                                Q(destination__icontains = self.request.GET.get('search')))
        else:
            queryset = Flights.objects.all()
        return queryset.order_by('-updated_at')


class CustomerBookedtickets(ViewSet):
    queryset = Booking.objects.all()
    def list(self, request):
        if self.request.GET.get('search'):
            queryset = Booking.objects.filter(booked_by=self.request.user.username)
            self.queryset = Booking.objects.filter(Q(name__icontains=self.request.GET.get('search'))|
                                                    Q(pnr_number__icontains=self.request.GET.get('search'))).order_by('-updated_at')
        else:
            self.queryset = Booking.objects.filter(booked_by=self.request.user.username).order_by('-updated_at')        
        serializer = UserBookedSerializer(self.queryset, many=True)
        return Response(serializer.data)

    # def create(self, request):
    #     pass

    def retrieve(self, request, pk=None):
        user_data = get_object_or_404(self.queryset, pk=pk)
        serializer = UserBookedSerializer(user_data)
        return Response(serializer.data)

    # def update(self, request, pk=None):
    #     pass

    def partial_update(self, request, pk=None):
        if request.GET.get('cancel') == 'cancel':
            if pk:
                try:
                    cancel = Booking.objects.get(id=pk)
                    cancel.booking_status = 'cancelled'
                    cancel.save()
                    return Response(status=status.HTTP_200_OK)
                except Exception as e:
                    context={}
                    context["error"] = str(e)
                    return Response(context,status=status.HTTP_400_BAD_REQUEST)
            else:
               return Response(status=status.HTTP_400_BAD_REQUEST)


    def delete(self, request, pk, format=None):
        user_data = get_object_or_404(Booking.objects.all(), pk=pk)
        user_data.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)



class CustomerAnalytics(APIView):
    def get(self,request):
        queryset = Booking.objects.filter(booked_by=self.request.user.username)
        queryset = queryset.annotate(month=ExtractMonth('created_at')).values('month').annotate(total=Count('id'))
        get_month = {1:'Jan', 2:'Feb', 3:'March', 4:'April', 5:'May', 6:'June',
                7:'July',8:'August',9:"Sep",10:"Oct",11:"Nov",12:"Dec"}
        data = []
        for key,value in get_month.items():
            for i in queryset:
                if key==i['month']:
                    data.append(i['total'])
                    break
            else:
                data.append(0)

        cancelled_data = Booking.objects.filter(booked_by=self.request.user.username,booking_status="cancelled")
        cancelled_data = cancelled_data.annotate(month=ExtractMonth('created_at')).values('month').annotate(total=Count('id'))
        can_data = []
        for key,value in get_month.items():
            for i in cancelled_data:
                if key==i['month']:
                    can_data.append(i['total'])
                    break
            else:
                can_data.append(0)

        context = {}
        context['data'] = data
        context['can_data'] = can_data
        context['month'] = get_month
        context['total_number_of_tickets'] = Booking.objects.filter(booked_by=self.request.user.username).count()
        context['total_spent_amount'] = Booking.objects.filter(booked_by=self.request.user.username).aggregate(Sum('flights__price'))['flights__price__sum']
        context['no_of_cancelled_tickets'] = Booking.objects.filter(booked_by=self.request.user.username,booking_status="cancelled").count()
        return JsonResponse(context, safe=False)
