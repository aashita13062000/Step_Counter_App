from django.urls import path
from customers import views
from .views import *
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
app_name='bookings'

router = routers.DefaultRouter()
router.register(r'airport-data', AdminCreateAirportDataView,basename="adminairport")
router.register(r'filght-data', AdminCreateFlightDataView,basename="adminflight")
router.register(r'booking-data', CustomerBookedtickets,basename="couster")


urlpatterns = [
    #  this urls changed to viewsets
    # path('v1/Admin-create-airport-data/',AdminCreateAirportDataView.as_view(),name = 'AdminCreateAirportDataView'),
    # path('v1/Admin-get-update-delete-airport-data/<str:country_code>/<str:airport_name>/',AdminGetUpdatedeleeteAirportDataView.as_view(),name = 'AdminGetUpdatedeleeteAirportDataView'),
    # path('v1/Admin-create-filght-data/',AdminCreateFlightDataView.as_view(),name = 'AdminCreateFlightDataView'),
    # path('v1/Admin-get-update-delete-flight-data/<str:flight_number>',AdminGetUpdatedeleeteFlightDataView.as_view(),name = 'AdminGetUpdatedeleeteFlightDataView'),

    #customer-booking
    path('v1/flightsearch/',SearchFlights.as_view(),name = 'flightsearch'),

    path('v1/customerbooking/',CustomerBooking.as_view(),name = 'customerbooking'),
    path('v1/customerbookingstatus/<str:pnr_number>/',CustomerBookingStatus,name = 'customerbookingstatus'),
    path('v1/customeranalytics/',CustomerAnalytics.as_view(),name = 'customeranalytics'),

]

urlpatterns+=router.urls