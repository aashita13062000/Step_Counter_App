from django.urls import reverse,resolve
from bookings.views import *
from django.test import SimpleTestCase

class TestUrls(SimpleTestCase):
    def test_airport_get(self):
        url=reverse("bookings:adminairport-list")
        self.assertEqual(resolve(url).func.cls ,AdminCreateAirportDataView)

    def test_flight_get(self):
        url=reverse("bookings:adminflight-list")
        self.assertEqual(resolve(url).func.cls ,AdminCreateFlightDataView)

    def test_flight_get(self):
        url=reverse("bookings:couster-list")
        self.assertEqual(resolve(url).func.cls ,CustomerBookedtickets)

    def test_customerbooking(self):
        url=reverse("bookings:customerbooking")
        self.assertEqual(resolve(url).func.cls ,CustomerBooking)

    def test_flightsearch(self):
        url=reverse("bookings:flightsearch")
        self.assertEqual(resolve(url).func.cls ,SearchFlights)

    def test_customerbookingstatus(self):
        url=reverse("bookings:customerbookingstatus")
        self.assertEqual(resolve(url).func.cls ,CustomerBookingStatus)

    def test_customerbookingstatus(self):
        url=reverse("bookings:customeranalytics")
        self.assertEqual(resolve(url).func.cls ,CustomerAnalytics)
