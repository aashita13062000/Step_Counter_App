from rest_framework.test import APITestCase
from bookings.models import Airports,Flights,Booking

# To test airport model(Table)
class TestAirportsModel(APITestCase):
    def setUp(self):
        self.airport_data={'country_code':"IN",'airport_name':"Banglore airport thoragallu,india"}

    def test_creates_user(self):
        airport = Airports.objects.create(**self.airport_data)
        self.assertIsInstance(airport,Airports)
        self.assertEqual(airport.country_code, self.airport_data['country_code'])

# To Test Flight model(Table)
class TestFlightsModel(APITestCase):
    def setUp(self):
        airport_data={'country_code':"IN",'airport_name':"Banglore airport thoragallu,india"}
        airport = Airports.objects.create(**airport_data)
        self.flight_data={"airport":airport,
                            "flight_number":1234567,
                            'depart_date_time':'2020-11-28 22:32',
                            'arival_date_time':'2020-11-29 10:59',
                            'origin':'Delhi',
                            'destination':'Banglore',
                            'price':'4000',
                            'city':'Banglore',
                            'airlines_name':'SpiceJet',
                            'aviliable_seats':'32',
                            }

    def test_creates_user(self):
        flight = Flights.objects.create(**self.flight_data)
        self.assertIsInstance(flight,Flights)
        self.assertEqual(flight.flight_number, self.flight_data['flight_number'])


# To Test Booking model(Table)
class TestBookingModel(APITestCase):
    def setUp(self):
        airport_data={'country_code':"IN",'airport_name':"Banglore airport thoragallu,india"}
        airport = Airports.objects.create(**airport_data)
        flight_data={"airport":airport,
                            "flight_number":1234567,
                            'depart_date_time':'2020-11-28 22:32',
                            'arival_date_time':'2020-11-29 10:59',
                            'origin':'Delhi',
                            'destination':'Banglore',
                            'price':'4000',
                            'city':'Banglore',
                            'airlines_name':'SpiceJet',
                            'aviliable_seats':'32',
                            }
        flight = Flights.objects.create(**flight_data)
        self.booking={
            "name":"booking1",
            "gender":"Male",
            "contact_number":"9535154327",
            "flights":flight,
            "DOB":"2001-12-29"
        }

    def test_creates_user(self):
        booking = Booking.objects.create(**self.booking)
        self.assertIsInstance(booking,Booking)
        self.assertEqual(booking.name, self.booking['name'])
