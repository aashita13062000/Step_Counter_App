from django.contrib.auth.models import User
from django.urls import reverse
from rest_framework import HTTP_HEADER_ENCODING,status
from rest_framework.authtoken.models import Token
from rest_framework.test import APITestCase
from customers.models import User
from bookings.models import Airports,Flights,Booking
import json

class AdminAirportDataTestCase(APITestCase):
    def setUp(self):
        self.airport_data = {'country_code':"IN",'airport_name':"Banglore airport thoragallu,india"}
        self.airport = Airports.objects.create(**self.airport_data)
        self.data = {"username": "test", 
                "email": "test@gmail.com",
                "password": "testuser",
                "is_superuser":True,
                "is_staff":True,
                "is_active":True,
                }
        self.user = User.objects.create_user(**self.data)
        #To Get Tokens
        username=self.data['username']
        password=self.data['password']
        token = self.client.post(path=reverse('token_obtain_pair'),data={"username":username,"password":password})
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {token.data['access']}")
        

    #Create Airport record
    def test_airport_create(self):
        airport_data = {'country_code':"IN",'airport_name':"Banglore airport,india"}
        response = self.client.post("/bookings/airport-data/", airport_data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    # list all Airport records
    def test_airport_list(self):
        response = self.client.get("/bookings/airport-data/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    # Retrive Single record
    def test_airport_retrive(self):
        response = self.client.get("/bookings/airport-data/{0}/".format(self.airport.id))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    # Update a record
    def test_airport_update(self):
        response = self.client.put("/bookings/airport-data/{0}/".format(self.airport.id),
                                                                        data=self.airport_data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    # delete Airport Record
    def test_airport_delete(self):
        response = self.client.delete("/bookings/airport-data/{0}/".format(self.airport.id))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)


class AdminflightDataTestCase(APITestCase):
    def setUp(self):
        self.airport_data = {'country_code':"IN",'airport_name':"Banglore airport thoragallu,india"}
        self.airport = Airports.objects.create(**self.airport_data)

        self.flight_data={"airport":self.airport,
                            "flight_number":1234567,
                            'depart_date_time':'2020-11-28 22:32',
                            'arival_date_time':'2020-11-29 10:59',
                            'origin':'Delhi',
                            'destination':'Banglore',
                            'price':'4000',
                            'city':'Banglore',
                            'airlines_name':'SpiceJet',
                            'aviliable_seats':'32',
                            }
        self.flight = Flights.objects.create(**self.flight_data)

        self.data = {"username": "test", 
                "email": "test@gmail.com",
                "password": "testuser",
                "is_superuser":True,
                "is_staff":True,
                "is_active":True,
                # "password2": "testuser"
                }

        self.user = User.objects.create_user(**self.data)

        #Get Access Tokens
        username=self.data['username']
        password=self.data['password']
        token = self.client.post(path=reverse('token_obtain_pair'),data={"username":username,"password":password})
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {token.data['access']}")

    #Create flight record
    def test_flight_create(self):
        airport_data = {'country_code':"IN",'airport_name':"Banglore,india"}
        airport = Airports.objects.create(**airport_data)

        flight_data = {"airport":airport,
                            "flight_number":132324234,
                            'depart_date_time':'2020-11-28 22:32',
                            'arival_date_time':'2020-11-29 10:59',
                            'origin':'Delhi',
                            'destination':'Banglore',
                            'price':'4000',
                            'city':'Banglore',
                            'airlines_name':'SpiceJet',
                            'aviliable_seats':'32',
                            'country_code':'IN',
                            'airport_name':self.airport.airport_name,
                            }

        response = self.client.post("/bookings/filght-data/", flight_data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
    
    # list all flight records
    def test_airport_list(self):
        response = self.client.get("/bookings/filght-data/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    # Retrive Single record
    def test_airport_retrive(self):
        response = self.client.get("/bookings/filght-data/{0}/".format(self.flight.id))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    # Update a record
    def test_airport_update(self):
        flight_data = {"airport":self.airport,
                            "flight_number":self.flight,
                            'depart_date_time':'2020-11-28 22:32',
                            'arival_date_time':'2020-11-29 10:59',
                            'origin':'Delhi',
                            'destination':'Bang',
                            'price':'4000',
                            'city':'Banglore',
                            'airlines_name':'SpiceJet',
                            'aviliable_seats':'31',
                            'country_code':'IN',
                            'airport_name':self.airport.airport_name,

                            }
        response = self.client.put("/bookings/filght-data/{0}/".format(self.flight.id),
                                                                        data=flight_data)
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    # delete flight Record
    def test_airport_delete(self):
        response = self.client.delete("/bookings/filght-data/{0}/".format(self.flight.id))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)




class CustomerBookingTestCase(APITestCase):
    def setUp(self):
        self.airport_data = {'country_code':"IN",'airport_name':"Banglore airport thoragallu,india"}
        self.airport = Airports.objects.create(**self.airport_data)

        self.flight_data={"airport":self.airport,
                            "flight_number":1234567,
                            'depart_date_time':'2020-11-28 22:32',
                            'arival_date_time':'2020-11-29 10:59',
                            'origin':'Delhi',
                            'destination':'Banglore',
                            'price':'4000',
                            'city':'Banglore',
                            'airlines_name':'SpiceJet',
                            'aviliable_seats':'32',
                            }
        self.flight = Flights.objects.create(**self.flight_data)

        self.data = {"username": "customerbooking", 
                "email": "customerbooking@gmail.com",
                "password": "testuser",
                "is_active":True,
                }

        self.user = User.objects.create_user(**self.data)

        #Get Access Tokens
        username=self.data['username']
        password=self.data['password']
        token = self.client.post(path=reverse('token_obtain_pair'),data={"username":username,"password":password})
        self.client.credentials(HTTP_AUTHORIZATION=f"Bearer {token.data['access']}")

    #Create customer booking multiple tickets record
    def test_customer_booking_multiple(self):
        booking = {"data":[{
                "name":"shiva",
                "gender":"Male",
                "contact_number":9535154327,
                "flight_number":self.flight.flight_number,
                "DOB":"2001-12-29"},
                {
                "name":"konanki",
                "gender":"Mal",
                "contact_number":9535154327,
                "flight_number":self.flight.flight_number,
                "DOB":"2001-12-29"  
                }]}
        response = self.client.post("/bookings/v1/customerbooking/", booking)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    #Create customer booking single tickets record
    def test_customer_single_booking(self):
        booking = {"data":[{
                "name":"shiva",
                "gender":"Male",
                "contact_number":9535154327,
                "flight_number":self.flight.flight_number,
                "DOB":"2001-12-29"}
            ]}
        response = self.client.post("/bookings/v1/customerbooking/", booking)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    # Get ticket status using PNR number
    def test_get_customer_details_using_PNR(self):
        data = {
                "name":"shiva",
                "gender":"Male",
                "contact_number":"9535154327",
                "flights":self.flight,
                "DOB":"2001-12-29",
                "pnr_number":21624555,
        }
        booking = Booking.objects.create(**data)
        response = self.client.get("/bookings/booking-data/?search={0}".format(booking.pnr_number))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    #search flights
    def test_get_customer_details_using_flight(self):
        response = self.client.get("/bookings/v1/flightsearch/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)


    #Get Booked tickets
    def test_get_customer_booked_tickets(self):
        response = self.client.get("/bookings/booking-data/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    # Retrive ticket booked record
    def test_ticket_booked_retrive(self):
        data = {
                "name":"shiva",
                "gender":"Male",
                "contact_number":"9535154327",
                "flights":self.flight,
                "DOB":"2001-12-29",
                "pnr_number":21624555,
        }
        booking = Booking.objects.create(**data)
        response = self.client.get("/bookings/filght-data/{0}/".format(booking.id))
        self.assertEqual(response.status_code, status.HTTP_200_OK)


    # Retrive ticket booked record for cancel 
    def test_ticket_booked_cancel(self):
        data = {
                "name":"shiva",
                "gender":"Male",
                "contact_number":"9535154327",
                "flights":self.flight,
                "DOB":"2001-12-29",
                "pnr_number":21624555,
        }
        booking = Booking.objects.create(**data)
        response = self.client.patch("/bookings/booking-data/{0}/?cancel=cancel".format(booking.id))
        self.assertEqual(response.status_code, status.HTTP_200_OK)

    # Retrive ticket booked record for cancel which is not present
    def test_ticket_booked_norecord_cancel(self):
        response = self.client.patch("/bookings/booking-data/{0}/?cancel=cancel".format(30000))
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    # delete customer Record
    def test_airport_delete(self):
        data = {
                "name":"shiva",
                "gender":"Male",
                "contact_number":"9535154327",
                "flights":self.flight,
                "DOB":"2001-12-29",
                "pnr_number":21624555,
        }
        booking = Booking.objects.create(**data)
        response = self.client.delete("/bookings/booking-data/{0}/".format(booking.id))
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)


    # negitive test case delete customer Record
    def test_with_norecord_airport_delete(self):
        response = self.client.delete("/bookings/booking-data/{0}/".format(23))
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    # customer analytics
    def test_customer_analytics(self):
        response = self.client.get("/bookings/v1/customeranalytics/")
        self.assertEqual(response.status_code, status.HTTP_200_OK)


    # delete customer Record
    def test_CustomerBookingStatus(self):
        data = {
                "name":"shiva",
                "gender":"Male",
                "contact_number":"9535154327",
                "flights":self.flight,
                "DOB":"2001-12-29",
                "pnr_number":21624555,
        }
        booking = Booking.objects.create(**data)
        response = self.client.get("/bookings/v1/customerbookingstatus/{0}/".format(booking.pnr_number))
        self.assertEqual(response.status_code, status.HTTP_200_OK)
