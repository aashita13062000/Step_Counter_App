const express = require('express')
const router = express.Router()
const historyHandler = require('../handler/history.js')
const historyController = require('../controller/historyController.js')
const auth = require('../middleware/auth')

// router.post('/createHistory',auth,historyHandler.createUserHistory)
router.post('/createNewHistory',auth,historyController.createNewUserHistory)
router.get('/getHistoryById',auth,historyHandler.getUserHistoryById)
router.delete('/deleteHistoryById',auth,historyHandler.deleteUserHistoryById)

module.exports = router