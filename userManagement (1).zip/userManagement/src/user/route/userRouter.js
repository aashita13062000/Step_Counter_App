const express = require('express')
const router = express.Router()
//const userController = require('../controller/userController')
const validation = require('../validation/validation.js')
const userHandler = require('../handler/handler.js')
const { upload } = require('../utils/multer.js')

// const multer = require('multer');
// const upload = multer({ dest: 'uploads'})

router.post('/addUser',upload.any(),validation.createUser,userHandler.createUser)
router.get('/getAllUsers',userHandler.findAllUsers)
router.get('/getUserById/:id',userHandler.findUserById)
router.patch('/updateUserById/:id',upload.any(),userHandler.updateUser)
router.delete('/deleteUserById/:id',userHandler.deleteUserById)
router.post('/login',userHandler.loginUser)


module.exports = router