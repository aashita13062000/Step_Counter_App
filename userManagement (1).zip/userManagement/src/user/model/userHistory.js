const mongoose = require("mongoose");


const historySchema = new mongoose.Schema({
  date: {
    type: Date,
    default: Date.now()
  },
  steps: {
    type: Number,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
  history:[{
    dateTime:{
        type: Date,
        default: Date.now
    },
    count:{
        type: Number
    }
}],
userId: {
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User'
  }



});

const history = mongoose.model("history", historySchema);

module.exports = history;


