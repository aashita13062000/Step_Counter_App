const userController = require("../controller/userController");
const validation = require("../validation/validation.js");
const { validationResult } = require("express-validator/check");

exports.createUser = async (req, res, next) => {
  try {
    console.log(req.body);

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.mapped() });
    }
    
    let user = await userController.createUser(req, res);
    res.send(user);
  } catch (err) {
    console.log(err);
    res.status(500).send(err);
  }
};

exports.findAllUsers = async (req, res, next) => {
  try {
    let users = await userController.findAllUsers(req, res);
    res.send(users);
  } catch (err) {
    console.log(err);
    res.status(500).send(err);
    next(err);
  }
};

exports.findUserById = async (req, res, next) => {
  try {
    let user = await userController.findUserById(req, res);
    res.send(user);
  } catch (err) {
    console.log(err);
    res.status(500).send(err);
    next(err);
  }
};

exports.updateUser= async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.mapped() });
    }
    let user = await userController.updateUser(req, res);
    res.send(user);
  } catch (err) {
    console.log(err);
    res.status(500).send(err);
  }
};

exports.deleteUserById = async (req, res) => {
  try {
    let user = await userController.deleteUserById(req, res);
    res.send(user);
  } catch (err) {
    console.log(err);
    res.status(500).send(err);
  }
};

exports.loginUser = async (req, res) => {
  try {
    let user = await userController.loginUser(req, res);
    res.send(user);
  } catch (err) {
    console.log(err);
    res.status(500).send(err);
  }
};


