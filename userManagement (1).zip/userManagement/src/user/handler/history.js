const historyController = require("../controller/historyController");

exports.createUserHistory  = async (req, res, next) => {
    try {
      let history = await historyController.createUserHistory(req, res);
      res.send(history);
    } catch (err) {
      console.log(err);
      res.status(500).send(err);
      next(err);
    }
  };

  exports.getUserHistoryById = async (req, res, next) => {
    try {
      let history = await historyController.getUserHistoryById(req, res);
      res.send(history);
    } catch (err) {
      console.log(err);
      res.status(500).send(err);
      next(err);
    }
  };

  exports.deleteUserHistoryById   = async (req, res, next) => {
    try {
      let history = await historyController.deleteUserHistoryById(req, res);
      res.send(history);
    } catch (err) {
      console.log(err);
      res.status(500).send(err);
      next(err);
    }
  };