const jwt = require('jsonwebtoken')
const User = require('../model/userModel')


const auth = async (req, res, next) => {
    try {
        const token = req.header('Authorization')
        if(!token){
            res.status(401).send({ error: 'Please authenticate.' })
        }
        const decoded = jwt.verify(token,'hellothere');
        const user= await User.findOne({ _id: decoded._id, 'tokens.token': token })

        

        if (!user) {
            throw new Error()
        }

        req.token = token
        req.body.loggedinUserId = decoded._id
        
        
        next()
    } catch (e) {
        res.status(401).send({ error: 'Invalid Token' })
    }
}

module.exports = auth