const User = require('../model/userModel.js')
const { check } = require('express-validator/check/index.js');


exports.createUser = [
    check('firstname')
    .notEmpty().withMessage('firstname should not be empty!')
    .isAlphanumeric().withMessage('firstname should be  an alphanumeric character')
    .isLength({ min: 0 , max: 50}).withMessage('firstname is greater than 3'),
    check('lastname')
    .notEmpty().withMessage('lastname should not be empty!')
    .isAlphanumeric().withMessage('lastname should be  an alphanumeric character')
    .isLength({ min: 0, max: 50}).withMessage('lastname is greater than 3'),
    check('username')
    .notEmpty().withMessage('username should not be empty!')
    .isAlphanumeric().withMessage('username should be  an alphanumeric character')
    .isLength({ min: 0, max: 20}).withMessage('username is greater than 3')
    .custom((value, {req}) => {
        return new Promise((resolve, reject) => {
          User.findOne({username:req.body.username}, function(err, user){
            if(err) {
              reject(new Error('Server Error'))
            }
            if(Boolean(user)) {
              reject(new Error('username already in use'))
            }
            resolve(true)
          });
        });
    }),
    check('password')
    .notEmpty().withMessage('password should not be empty!')
    .matches(/^(?:(?<Numbers>[0-9]{1})|(?<Alpha>[a-zA-Z]{1})|(?<Special>[^a-zA-Z0-9]{1})){6,12}$/).withMessage('password is not correct!'),
    check('address')
    .notEmpty().withMessage('address should not be empty!')
    .isLength({ min: 3 , max: 200}).withMessage('address is greater than 3')  
];


exports.updateUser = [
    check('firstname')
    .notEmpty().withMessage('firstname should not be empty!')
    .isAlphanumeric().withMessage('firstname should be  an alphanumeric character')
    .isLength({ min: 3 , max: 50}).withMessage('firstname is greater than 3'),
    check('lastname')
    .notEmpty().withMessage('lastname should not be empty!')
    .isAlphanumeric().withMessage('lastname should be  an alphanumeric character')
    .isLength({ min: 3, max: 50}).withMessage('lastname is greater than 3'),
    check('username')
    .notEmpty().withMessage('username should not be empty!')
    .isAlphanumeric().withMessage('username should be  an alphanumeric character')
    .isLength({ min: 0, max: 20}).withMessage('username is greater than 3')
    .custom((value, {req}) => {
        return new Promise((resolve, reject) => {
          User.findOne({username:req.body.username}, function(err, user){
            if(err) {
              reject(new Error('Server Error'))
            }
            if(Boolean(user)) {
              reject(new Error('username already in use'))
            }
            resolve(true)
          });
        });
    }),
    check('password')
    .notEmpty().withMessage('password should not be empty!')
    .matches(/^(?:(?<Numbers>[0-9]{1})|(?<Alpha>[a-zA-Z]{1})|(?<Special>[^a-zA-Z0-9]{1})){6,12}$/),
    check('address')
    .notEmpty().withMessage('address should not be empty!')
    .isLength({ min: 3 , max: 200}).withMessage('address is greater than 3')  
];




