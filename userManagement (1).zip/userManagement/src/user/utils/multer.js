const multer = require("multer");
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads");
  },
  filename: (req, file, cb) => {
    cb(null,  Date.now() + '-' + file.originalname);
  }
});
const multerFilter = (req, file, cb) => {
  if (!file.originalname.match(/\.(jpg|jpeg|png)$/)) {
    cb(new Error("Not a jpeg File!!"), false);
  }
  cb(null, true);
};

const upload = multer({
  storage: storage,
  fileFilter: multerFilter,
});


exports.upload = upload;
