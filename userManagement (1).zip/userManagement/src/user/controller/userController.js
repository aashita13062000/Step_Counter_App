const userDao = require("../dao/userDao");


//creating a new user
exports.createUser = async (req, res) => {
  
  if (req.files != null) {
    
    try {
      // console.log("firstName: ====", req.body.firstname);
      // console.log("lastName: ====", req.body.lastname)
      // console.log("file1 ====", req.files);
      // console.log("filenames: ====", req.files[0].filename)
      const user = await userDao.createUser({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        userName: req.body.userName,
        password: req.body.password,
        address:req.body.address,
        image:{ name :req.files[0].filename}
      });
      res.send({
        status : 200,
        data:{
          user
        }
      })
    } catch (err) {
      res.status(400).send({ error: err.message });
    }
  } else {
    try {
      let user = await userDao.createUser(req.body);
      res.send({
        status: 200,
        data: {
          user
        }
      });
    } catch (err) {
      console.log(err);
      res.status(500).send(err);
    }
  }
};

//find all users
exports.findAllUsers = async (req, res) => {
  try {
    let users = await userDao.findAllUsers(req.body);
    res.send({
      status: 200,
      data: {
        users,
      },
    });
  } catch (err) {
    console.log(err);
    res.status(500).send(err);
  }
};

//find user by their id 
exports.findUserById = async (req, res) => {   
    try{
      let user = await userDao.findUserById(req.params.id);
      if(user != null){
        res.send({
          status: 200,
          data: {
            user,
          },

      })
      
      };

   }catch(err){
      res.status(500).send({message: 'User not found'});

    }
  
}

//updating existing user by their id
exports.updateUser = async (req, res) => {
  try{
    const user = await userDao.updateUser(req.params.id,req.body)
    if(user !=null){
      res.send(user)
    }
    res.send({message: 'User not found'});
  }catch(err){
    res.status(500).send(err)
  }
}

//deleting user by their id
exports.deleteUserById = async (req, res) => {
    try {
      let user = await userDao.deleteUserById(req.params.id);
      if(user != null) {
        res.send({ message: "User deleted successfully" });
      }
      
    } catch (err) {
      console.log(err);
      res.status(500).send(err);
    }

  
};

//login user with username and password and generating jwt token
exports.loginUser = async (req, res) => {
  try {
    let user = await userDao.loginUser(req.body.username, req.body.password);
    const token = await user.generateAuthToken()
    // res.send(user)
    res.send({ user, token })
  } catch (err) {
    console.log(err);
    res.status(500).send(err);
  }


};

