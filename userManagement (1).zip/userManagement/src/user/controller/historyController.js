const historyDao = require("../dao/historyDao");
const mongoose = require('mongoose');
const { count } = require("../model/userModel");

// exports.createUserHistory = async (req,res) =>{
//     try{
//         let history = await historyDao.createUserHistory({
//             date: new Date(req.body.date),
//             history:req.body.history,
//             userId:mongoose.Types.ObjectId(req.body.loggedinUserId)
//         });
//     res.send(history)
//     }catch(err){
//         console.log(err);
//      res.status(500).send(err);

//     }
// }
exports.createNewUserHistory = async(req,res)=>{
    const history = historyDao.createNewUserHistory(history.userId.toString(),history)
    if(!history){
        const newHistory = new History()
        newHistory.save()
    }
    res.send(history)

}


exports.createNewUserHistory = async(req,res)=>{
    try{
        let history = await historyDao.createNewUserHistory({
            history:req.body.history,
            userId:mongoose.Types.ObjectId(req.body.loggedinUserId)
        });
    res.send(history)
    }catch(err){
        console.log(err);
     res.status(500).send(err);

    }
}

exports.getUserHistoryById = async (req, res) =>{
    try{
        const history= await historyDao.getUserHistoryById(req.params.id)
        .populate({ path: 'userId', select: 'username' })
        .lean()
        .exec(function (err, history) {
          if (!history) {
            return res.status(404).send({error:'Data not Found'})
        }
        history.name=history.userId.username
        delete history.userId;
        res.send(history)
  });

    }catch(err){
        res.status(500).send({ error: 'Enter Valid Id!' })
    }
}

exports.deleteUserHistoryById = async (req, res) =>{
    try{
        const history = await historyDao.deleteUserHistoryById(req.params.id)

        if (!history) {
            return res.status(404).send({error:'Please, enter correct Id!'})
        }
  
        res.status(200).send({success:'Record deleted successfully'})
        
    }catch(err){

    }
}

