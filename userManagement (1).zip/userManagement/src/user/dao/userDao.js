const User = require('../model/userModel.js')

function createUser(user){
    return User.create(user)
}

function findAllUsers(){
    return User.find()
}

function findUserById(id){
    return User.findById(id)
}

function updateUser(id,user){
    return User.findOneAndUpdate(id,user)
}

function deleteUserById(id){
    return User.findByIdAndRemove(id)
}

function loginUser(username, password){
    return User.findByCredentials(username, password)
}
 


module.exports = {
 
    createUser,
    findAllUsers,
    findUserById,
    updateUser,
    deleteUserById,
    loginUser
}

