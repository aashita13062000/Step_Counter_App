const History = require('../model/userHistory.js')

// function createUserHistory(history){
//    // return History.findOneAndUpdate(history.userId, history)
//    console.log("Test Doc : ",history);
//    console.log("Test Doc : ",history.userId.toString());
//     History.findOneAndUpdate( 
//         {userId:history.userId.toString()}, history, function (err, result) {
//         if (err){
//             console.log(err)
//         }
//         else{
//             if(!result){

//             }
//         }
//     });
// }

function createNewUserHistory(userId,history) {
    return History.findOneAndUpdate(userId, history)

}

function getUserHistoryById(_id){
    return History.findById(_id)
}
function deleteUserHistoryById(_id){
    return History.findByIdAndRemove(_id)
}

module.exports = {
    // createUserHistory,
    createNewUserHistory,
    getUserHistoryById,
    deleteUserHistoryById,
}