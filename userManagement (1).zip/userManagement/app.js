const express = require("express");
const app = express();
require('./startup/db.js')
const bodyParser = require('body-parser');



const userRouter = require('./src/user/route/userRouter.js')
const historyRouter = require('./src/user/route/historyRouter.js')

 const sessions = require('express-session');
 const cookieParser = require("cookie-parser");



//app.use(express.json())
app.use('/uploads', express.static('uploads'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(userRouter,historyRouter)

app.use(cookieParser());

const oneDay = 1000 * 60 * 60 * 24;
app.use(sessions({
  secret: "hellothere",
  saveUninitialized:true,
  cookie: { maxAge: oneDay },
  resave: false 
}));


const port = process.env.PORT || 8081;


app.listen(port, () => {
    console.log("server listening on port " + port);
  });
